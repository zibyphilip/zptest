package com.worldpay.bcs;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import org.eclipse.microprofile.rest.client.ext.ClientHeadersFactory;

@ApplicationScoped
public class RequestHeaderFactory implements ClientHeadersFactory {

    @Override
    public MultivaluedMap<String, String> update(MultivaluedMap<String, String> incomingHeaders, MultivaluedMap<String, String> clientOutgoingHeaders) {
        MultivaluedMap<String, String> result = new MultivaluedHashMap<>();
        result.add("Authorization", "Basic OTAwODQ4NzktMDljNy00ZTVjLTk4ZGYtN2YyZTllM2MyY2FlOm5BUE9QaDlWcDgxMFFMQzRnMmFPMGFZY1d4alJCQ3lkYnBOYUNsWFI=");
        return result;
    }
}