package com.worldpay.bcs;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
public class DocumentDecisionService {

    @Inject
    @RestClient
    DocumentService documentService;

    @Fallback(fallbackMethod = "missingQuestionAnswers")
    public List<String> executeDecision(QuestionAnswers questionAnswers) {
        log.info(" ==================== DocumentDecisionService : {}", questionAnswers);
        try {
            var jsonNode = documentService.executeDecision(questionAnswers);
            log.info(" ==================== DocumentDecisionService invoked successfully =========== ");
            var objectMapper = new ObjectMapper();
            var documents = objectMapper.readValue(objectMapper.writeValueAsString(jsonNode.path("documents")), List.class);
            log.info(" ==================== DocumentDecisionService documents =========== {}", documents);
            return documents;
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return null;
    }

    public List<String> missingQuestionAnswers(QuestionAnswers questionAnswers) {
        log.info(" ==================== DocumentDecisionService Fall back : {}", questionAnswers);
        return null;
    }
}