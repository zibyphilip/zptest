package com.worldpay.bcs;

import org.kie.api.project.KieActivator;

@KieActivator
public class Activator {
    
}
