package com.worldpay.bcs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class QuestionAnswer implements Serializable {

    private String referenceId;
    private String proofOfBusinessInclude;
       
}
