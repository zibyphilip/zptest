package com.worldpay.bcs;

import org.eclipse.microprofile.rest.client.annotation.RegisterClientHeaders;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
import org.jboss.resteasy.annotations.jaxrs.PathParam;
import com.fasterxml.jackson.databind.JsonNode;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("/api")
@RegisterRestClient(configKey="watchlist-api")
@RegisterClientHeaders(RequestHeaderFactory.class)
public interface WatchlistRemoteService {

    @GET
    @Path("/v1/uk/companies/regnum={regnum}")
    JsonNode getByRegNum(@PathParam String regnum);
}
