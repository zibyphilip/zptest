package com.worldpay.bcs;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.WebApplicationException;

import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
public class WatchlistService {

    @Inject
    @RestClient
    WatchlistRemoteService watchlistRemoteService;

    @Fallback(fallbackMethod = "missingRegNum")
    public JsonNode getByRegNum(String regnum) {
        log.info(" ==================== WatchlistService regNum : {}", regnum);
        JsonNode jsonNode = null;
        try {
            jsonNode = watchlistRemoteService.getByRegNum(regnum);
        } catch (Exception e) {
            var objectMapper = new ObjectMapper();
            //var exceptionJson = objectMapper.createObjectNode();
            if(e instanceof WebApplicationException) {
                var response = ((WebApplicationException) e).getResponse();
                //MyErrorEntity entity = response.readEntity(MyErrorEntity.class);
                //exceptionJson.put("message", response.getEntity().toString());
                var str = "{\"message\": \"" + response.getStatusInfo().getReasonPhrase() + "\"}";
                try {
                    jsonNode = objectMapper.readTree(str);
                    log.info("========= jsonNode ======= {}" , jsonNode);
                } catch (Exception ex) {
                   ex.printStackTrace();
                }    
            }            
        }
        
        log.info(" ==================== WatchlistService invoked successfully =========== ");
        return jsonNode;
    }

    public JsonNode missingRegNum(String regnum) {
        log.info(" ==================== WatchlistService Fall back : {}", regnum);
        return null;
    }
}