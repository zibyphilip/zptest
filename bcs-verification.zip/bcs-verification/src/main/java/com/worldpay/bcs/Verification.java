package com.worldpay.bcs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Verification implements Serializable {

    private String country;
    private String legalEntityCounterPart;
    
}
