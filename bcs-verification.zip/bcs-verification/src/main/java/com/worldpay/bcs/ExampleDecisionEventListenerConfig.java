package com.worldpay.bcs;

import javax.enterprise.context.ApplicationScoped;

import org.kie.kogito.dmn.config.CachedDecisionEventListenerConfig;

@ApplicationScoped
public class ExampleDecisionEventListenerConfig extends CachedDecisionEventListenerConfig {

    public ExampleDecisionEventListenerConfig() {
        register(new LoggingDMNRuntimeEventListener("ExampleDecisionEventListenerConfig's inner listener #1"));
        // register(new LoggingDMNRuntimeEventListener("ExampleDecisionEventListenerConfig's inner listener #2"));
    }

}
