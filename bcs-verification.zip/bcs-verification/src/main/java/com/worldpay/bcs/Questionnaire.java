package com.worldpay.bcs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Questionnaire implements Serializable {

    private String referenceId;
    private String question;
    private List<String> allowedValues;
    private String multiReferenceIds;   
    
}
