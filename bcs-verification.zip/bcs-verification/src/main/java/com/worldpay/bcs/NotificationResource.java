package com.worldpay.bcs;
import io.quarkus.mailer.Mail;
import io.quarkus.mailer.Mailer;
import io.smallrye.common.annotation.Blocking;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;


@Slf4j
@Path("/mail")                                                          
public class NotificationResource {

    @Inject Mailer mailer;                                              

    @GET                                                                
    @Blocking                                                           
    public void sendEmail() {
        log.info("===========================Before Sending Email======================================");
        mailer.send(
                Mail.withText("vijayabhaskarreddy.bathena@fisglobal.com",                     
                    "Notification from Business User",
                    "A simple email sent from a Quarkus application."
                )
        );
        log.info("===========================Email Sent================================================");
    }

}