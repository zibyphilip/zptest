package com.worldpay.bcs;

import org.kie.dmn.api.core.event.AfterEvaluateAllEvent;
import org.kie.dmn.api.core.event.AfterEvaluateContextEntryEvent;
import org.kie.dmn.api.core.event.AfterEvaluateDecisionEvent;
import org.kie.dmn.api.core.event.AfterEvaluateDecisionTableEvent;
import org.kie.dmn.api.core.event.BeforeEvaluateAllEvent;
import org.kie.dmn.api.core.event.BeforeEvaluateContextEntryEvent;
import org.kie.dmn.api.core.event.BeforeEvaluateDecisionEvent;
import org.kie.dmn.api.core.event.BeforeEvaluateDecisionTableEvent;
import org.kie.dmn.api.core.event.DMNRuntimeEventListener;

import lombok.extern.slf4j.Slf4j;

@Slf4j
class LoggingDMNRuntimeEventListener implements DMNRuntimeEventListener {

    private final String name;

    public LoggingDMNRuntimeEventListener(String name) {
        this.name = name;
    }

    @Override
    public void beforeEvaluateDecision(BeforeEvaluateDecisionEvent event) {

        //log.info("=============== BeforeEvaluateDecisionEvent: {}", event.getResult().toString());
    }

    @Override
    public void afterEvaluateDecision(AfterEvaluateDecisionEvent event) {
        //log.info("===============  AfterEvaluateDecisionEvent: {}", event.getResult().toString());
    }

    @Override
    public void beforeEvaluateContextEntry(BeforeEvaluateContextEntryEvent event) {
        // log("BeforeEvaluateContextEntryEvent");
    }

    @Override
    public void afterEvaluateContextEntry(AfterEvaluateContextEntryEvent event) {
        // log("AfterEvaluateContextEntryEvent");
    }

    @Override
    public void beforeEvaluateDecisionTable(BeforeEvaluateDecisionTableEvent event) {
        // log("BeforeEvaluateDecisionTableEvent");
    }

    @Override
    public void afterEvaluateDecisionTable(AfterEvaluateDecisionTableEvent event) {
        // log("AfterEvaluateDecisionTableEvent");
    }

    @Override
    public void beforeEvaluateAll(BeforeEvaluateAllEvent event) {
        // log("BeforeEvaluateAllEvent");
    }

    @Override
    public void afterEvaluateAll(AfterEvaluateAllEvent event) {
        // log("AfterEvaluateAllEvent");
    }

    private void log(String event) {
        log.info("{} received by {}", event, name);
    }

}
