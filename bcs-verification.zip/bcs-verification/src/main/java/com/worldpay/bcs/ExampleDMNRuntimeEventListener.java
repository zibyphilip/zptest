package com.worldpay.bcs;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ExampleDMNRuntimeEventListener extends LoggingDMNRuntimeEventListener {

    public ExampleDMNRuntimeEventListener() {
        super("ExampleDMNRuntimeEventListener");
    }

}
